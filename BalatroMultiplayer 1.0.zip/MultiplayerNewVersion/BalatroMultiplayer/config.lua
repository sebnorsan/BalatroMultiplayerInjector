return {
	["username"] = "Guest",
	["server_url"] = "balatro.virtualized.dev",
	["server_port"] = 8788,
}
