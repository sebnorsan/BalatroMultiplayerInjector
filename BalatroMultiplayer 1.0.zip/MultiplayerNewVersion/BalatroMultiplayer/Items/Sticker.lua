SMODS.Atlas({
	key = "sticker_mp",
	path = "sticker_mp.png",
	px = 71,
	py = 95,
})

SMODS.Sticker({
	key = "sticker",
	atlas = "sticker_mp",
	badge_colour = G.C.MULITPLAYER,
	default_compat = false,
	needs_enable_flag = true,
	hide_badge = true,
})
