# A Balatro Multiplayer Mod

This is an **WIP** Balatro multiplayer mod developed by virtualized and TGMM.

If you want to get in touch for any reason add `virtualized` on discord or send an email to `v@virtualized.dev`.

## Do not download the mod from this github unless you know what you are doing! Join the discord server below and download the mod through there:

https://discord.gg/W22FEqVWsq

## Licenced under [GNU GPL 3.0](https://github.com/V-rtualized/balatro-multiplayer/blob/main/LICENSE.md)
