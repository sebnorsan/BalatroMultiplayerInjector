---@meta lovely

local lovely = {}

---@type string
--- Lovely version. 
lovely.version = ""

---@type string
--- Current mod directory. 
lovely.mod_dir = ""

---@type string
--- Link to the Lovely GitHub repository. 
lovely.repo = ""

return lovely